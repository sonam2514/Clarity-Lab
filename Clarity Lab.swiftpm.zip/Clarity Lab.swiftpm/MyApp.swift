import SwiftUI

@main
struct ClarityLabApp: App {
    var body: some Scene {
        WindowGroup {
            MainContainerView()
        }
    }
}

