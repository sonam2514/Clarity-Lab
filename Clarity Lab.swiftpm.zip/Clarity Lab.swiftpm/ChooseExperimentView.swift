import SwiftUI

struct ChooseExperimentView: View {
    
    @Binding var logs: [SessionLog]
    
    private let experiments: [Experiment] = [
        Experiment(
            title: "25 Mins Study Session vs 45 Mins Study Session",
            variations: ["25 Minutes Study Session", "45 Minutes Study Session"]
        ),
        Experiment(
            title: "Morning Study vs Night Study",
            variations: ["Morning Study", "Night Study"]
        ),
        Experiment(
            title: "Music vs Silence",
            variations: ["Music", "Silence"]
        ),
        Experiment(
            title: "Short Breaks vs Long Breaks",
            variations: ["Short Breaks", "Long Breaks"]
        ),
        Experiment(
            title: "8 Hours Sleep vs 6 Hours Sleep",
            variations: ["8 Hours Sleep", "6 Hours Sleep"]
        )
    ]
    
    var body: some View {
        
        ZStack {
            
            // Same deep purple background as LogSession
            LinearGradient(
                colors: [
                    Color(red: 0.18, green: 0.12, blue: 0.35),
                    Color(red: 0.28, green: 0.20, blue: 0.55)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 35) {
                
                // Section Heading
                VStack(spacing: 8) {
                    
                    Text("Choose Your Experiment")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(Color.white.opacity(0.95))
                    
                    Text("Compare two routines and measure the difference.")
                        .font(.system(size: 14))
                        .foregroundColor(Color.white.opacity(0.65))
                }
                .padding(.top, 10)
                
                // Experiment Cards
                VStack(spacing: 18) {
                    
                    ForEach(experiments) { experiment in
                        
                        NavigationLink {
                            LogSessionView(
                                experiment: experiment,
                                logs: $logs
                            )
                        } label: {
                            
                            HStack {
                                Text(experiment.title)
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundColor(.white)
                                
                                Spacer()
                                
                                Image(systemName: "chevron.right")
                                    .foregroundColor(Color.white.opacity(0.6))
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color.white.opacity(0.08))
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.white.opacity(0.15))
                            )
                        }
                    }
                }
                
                Spacer()
            }
            .padding(24)
        }
    }
}

